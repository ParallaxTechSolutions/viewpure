import React, { Component } from "react";

export default class Footer extends Component {
  render() {
    return (
      <footer class="footer">
        <div class="row">
          <div class="footer-links large-6 small-12 text-center-small-only columns">
            <a href="http://www.viewpure.com/pages/membership">
              <font color="red">*NEW School and District Plans</font>
            </a>{" "}
            / <a href="https://members.viewpure.com/signup">Free Membership</a>{" "}
            / <a href="http://www.viewpure.com">Search</a> /{" "}
            <a href="http://viewpure.com/pages/teacher-resources-chooser/">
              Teacher Resources
            </a>{" "}
            / <a href="http://viewpure.com/pages/blog-chooser/">Blog</a> /{" "}
            <a href="http://www.viewpure.com/pages/about-us" target="_blank">
              About Us
            </a>{" "}
            /{" "}
            <a href="http://www.viewpure.com/pages/contact-us" target="_blank">
              Contact
            </a>{" "}
            /{" "}
            <a
              href="http://www.viewpure.com/pages/terms-privacy"
              target="_blank"
            >
              Privacy Policy
            </a>{" "}
            /{" "}
            <a
              href="http://www.viewpure.com/pages/terms-privacy"
              target="_blank"
            >
              Terms of Service
            </a>
            <br />
            <br />
            <br />
            <br />
            <br />
            Youtube is the source of relevant content
          </div>
          <div class="copyright offset-1 large-6 small-12 text-center-small-only columns text-right">
            &copy; 2010 - <span class="span-view">View</span>
            <span class="span-pure">Pure</span>.
          </div>
          <div>
            <br />
            <br />
            <br />
          </div>
        </div>
      </footer>
    );
  }
}
