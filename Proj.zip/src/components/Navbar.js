import React, { Component } from "react";

export default class Navbar extends Component {
  render() {
    return (
      <div className="row">
        <div className="large-3 columns logoo">
          <a href="http://viewpure.com">
            <img src="http://www.viewpure.com/assets/img/viewpure-logo.png"></img>
          </a>
        </div>
        <div className="large-6 large-offset-1 columns nav6">
          <ul className="nav">
            <li className="newschool">
              <a href="http://www.viewpure.com/pages/membership" className="ab">*NEW School and District Plans</a>
            </li>
            <li >
              <a href="http://members.viewpure.com/signup" className="freemember">FREE Membership</a>
            </li>
            <br></br>
            <li>
              <a href="http://viewpure.com/pages/teacher-resources-chooser/">
                Teacher Resources
              </a>
            </li>
            <li>
              <a href="http://viewpure.com/pages/blog-chooser/">Blog</a>
            </li>
            <li>
              <a href="https://members.viewpure.com/signin/">Sign-In</a>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}
