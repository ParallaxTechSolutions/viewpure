import React from "react";
import logo from "./logo.svg";
import "./App.css";
import "./style.css";
import "./foundation.css";
import "./index.css";
import OopsPage from "./components/OopsPage";
import {
  BrowserRouter as Router,
  Route,
  Link,
  browserHistory,
  IndexRoute,
  Switch,
} from "react-router-dom";
import Home from "./components/Home";
import ThirdPage from "./components/ThirdPage";
import VideoPlayer from "./components/VideoPlayer";
import Search from "./components/Search";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/thirdpage" component={ThirdPage} />
        <Route path="/play" component={VideoPlayer} />
        <Route path="/search" component={Search} />
        <Route path="*" component={OopsPage} />
      </Switch>
    </Router>
  );
}

export default App;
