import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  browserHistory,
  IndexRoute,
  Switch,
} from "react-router-dom";
export default class ThirdPage extends Component {
  render() {
    return (
      <div>
        <h1>THIRD PAGE</h1>
        <Link to="/">Home</Link>
      </div>
    );
  }
}
