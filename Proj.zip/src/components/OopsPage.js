import React, { Component } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default class OopsPage extends Component {
  render() {
    return (
      <header className="header row">
        <Navbar />
        <div className="container page-title">
          <div className="row">
            <div className="large-12 columns text-left">
              <h2 className="pagenotfound">Page Not Found</h2>
            </div>
          </div>
        </div>
        <div className="addcon last-row page-caption">
          <div className="row">
            <div className="pagenottext">
              Looks like we couldn't locate the page or video you were looking
              for..
            </div>
          </div>
        </div>
        <div className="row">
          <div className="large-12 columns text-center">
            <div className="fourohfour">
              <br></br>
              <h2 className="lookslike">
                Lost the video or page you were looking for...
              </h2>
              <p className="tryfaq">
                Try the{" "}
                <a href="<?php echo genURL($vp->url, 'faq') . '?ref=oops'; ?>">
                  FAQ page
                </a>{" "}
                to answer any unanswered questions.
              </p>
              <br></br>
            </div>
          </div>
        </div>
        <Footer />
      </header>
    );
  }
}
