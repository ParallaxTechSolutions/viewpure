import React, { Component } from "react";
import { connect } from "react-redux";
import Footer from "./Footer";

class VideoPlayer extends Component {
  render() {
    console.log("PROPS", this.props.VideoData);
    const ifrSrc =
      "//www.youtube-nocookie.com/embed/" +
      this.props.VideoData.id +
      "?rel=0&amp;modestbranding=1&amp;hd=1&amp;showinfo=0&amp;controls=1&amp;iv_load_policy=3&amp;wmode=transparent&amp;autohide=1&amp;autoplay=0";
    return (
      <div>
        <div className="h3"></div>
        <header className="header condensed row">
          <div className="row prim">
            <div className="large-3 columns">
              <h1 className="logo">
                <a href="http://viewpure.com">
                  <span className="span-view">View</span>
                  <span className="span-pure">Pure</span>
                </a>
                <span className="dev-status">beta</span>
              </h1>
            </div>
            <div className="large-6 large-offset-3 columns">
              <ul className="nav">
                <li>
                  <a href="http://www.viewpure.com/pages/membership">
                    <font color="#f2670a">
                      <b>*NEW School and District Plans</b>
                    </font>
                  </a>
                </li>
                <li>
                  <a href="http://members.viewpure.com/signup">
                    FREE Membership
                  </a>
                </li>
                <li>
                  <a href="http://viewpure.com/pages/teacher-resources-chooser/">
                    Teacher Resources
                  </a>
                </li>
                <li>
                  <a href="http://viewpure.com/" target="_blank">
                    Search
                  </a>
                </li>
                <li>
                  <a
                    href="<br />
<b>Notice</b>:  Undefined variable: video in <b>/home/tubeqtng/viewpure.com/inc/layout/header.lay.php</b> on line <b>35</b><br />
<br />
<b>Notice</b>:  Trying to get property of non-object in <b>/home/tubeqtng/viewpure.com/inc/layout/header.lay.php</b> on line <b>35</b><br />
"
                    target="_blank"
                  >
                    On YouTube
                  </a>
                </li>
                <li>
                  <a href="http://viewpure.com/live">Live</a>
                </li>
                <li>
                  <a href="#" className="sc-sh">
                    Share
                  </a>
                </li>
                <li>
                  <a href="https://members.viewpure.com/signin/">Sign-In</a>
                </li>
              </ul>
            </div>
          </div>

          <div className="row social-share">
            <div className="large-4 large-centered sc-bx">
              <div className="row">
                <div className="social-block facebook small-3 columns">
                  <div
                    className="fb-share-button"
                    data-href="http://www.viewpure.com/asm436D-5Rc?start=0&end=0"
                    data-width="150"
                    data-layout="button_count"
                    data-show-faces="false"
                    data-send="false"
                  ></div>
                </div>
                <div className="social-block twitter small-3 columns">
                  <a
                    href="https://twitter.com/share"
                    className="twitter-share-button"
                  >
                    Tweet
                  </a>
                </div>
              </div>
              <div className="social-block pinterest small-3 columns">
                <a
                  href="//pinterest.com/pin/create/button/?url=http%3A%2F%2Fwww.viewpure.com%2Fasm436D-5Rc%3Fstart%3D0%26end%3D0&amp;media=<br />
<b>Notice</b>:  Undefined variable: video in <b>/home/tubeqtng/viewpure.com/inc/layout/header.lay.php</b> on line <b>56</b><br />
<br />
<b>Notice</b>:  Trying to get property of non-object in <b>/home/tubeqtng/viewpure.com/inc/layout/header.lay.php</b> on line <b>56</b><br />
&amp;description=<br />
<b>Notice</b>:  Undefined variable: video in <b>/home/tubeqtng/viewpure.com/inc/layout/header.lay.php</b> on line <b>56</b><br />
<br />
<b>Notice</b>:  Trying to get property of non-object in <b>/home/tubeqtng/viewpure.com/inc/layout/header.lay.php</b> on line <b>56</b><br />
"
                  data-pin-do="buttonPin"
                  data-pin-config="beside"
                >
                  <img src="//assets.pinterest.com/images/pidgets/pin_it_button.png" />
                </a>
              </div>
            </div>
          </div>
        </header>
        <div className="videoblog">
          <iframe
            className="ifram5"
            src={ifrSrc}
            frameborder="0"
            allowfullscreen
          ></iframe>
        </div>
        <div id="">
          <div className="row">
            <div className="columns large-12 large-centered video-out">
              <div className="video">
                <div className="row">
                  <div className="large-12 large-centered">
                    <div className="filter">
                      <div className="row">
                        <div className="large-12 columns large-centered pdf1">
                          <form
                            name="vp-home"
                            className="vp-home"
                            action="./addToPlaylist"
                            method="post"
                          >
                          
                            <div className="row innerpdf menurow1">
                              <div className="columns large-8">
                                <div className="row">
                                  <div className="columns small-5">
                                    <span className="prefix left-radius margin-right-in spanbtn">
                                      viewpure.com/
                                    </span>
                                  </div>
                                  <div className="columns small-7">
                                    <input
                                      type="text"
                                      className="right-radius margin-left-in"
                                      name="customURL"
                                      placeholder="Enter custom URL"
                                      value=""
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="columns large-4">
                                <input
                                  type="text"
                                  name="password"
                                  placeholder="Enter password to protect"
                                />
                              </div>
                            </div>
                            <div className="row innerpdf menurow1">
                              <div className="columns large-6">
                                <div className="row collapse">
                                  <div className="columns small-6">
                                    <span className="prefix left-radius spanbtn">
                                      Start Time
                                    </span>
                                  </div>
                                  <div className="columns small-3">
                                    <input
                                      type="text"
                                      className="no-radius text-right margin-right-in"
                                      name="startMin"
                                      placeholder="Min"
                                      value=""
                                    />
                                    <span className="time-sep">:</span>
                                  </div>
                                  <div className="columns small-3">
                                    <input
                                      type="text"
                                      className="right-radius margin-left-in"
                                      name="startSec"
                                      placeholder="Sec"
                                      value=""
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="columns large-6">
                                <div className="row">
                                  <div className="columns small-6">
                                    <span className="prefix left-radius spanbtn">
                                      End Time
                                    </span>
                                  </div>
                                  <div className="columns small-3">
                                    <input
                                      type="text"
                                      className="no-radius text-right margin-right-in"
                                      name="endMin"
                                      placeholder="Min"
                                      value=""
                                    />
                                    <span className="time-sep">:</span>
                                  </div>
                                  <div className="columns small-3">
                                    <input
                                      type="text"
                                      className="right-radius margin-left-in"
                                      name="endSec"
                                      placeholder="Sec"
                                      value=""
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="">  
                            <p align="right">
                                <font color="red">
                                  <b>*Cool New Features</b>
                                </font>
                              </p></div>
                  <div className="row">
                                <div align="right"> 
                                <input
                                  type="submit"
                                  name="submit"
                                  id="home-submit"
                                  className="button success btn12"
                                  value="Add to Playlist"
                                />
  &nbsp;&nbsp;
                                <input
                                  type="submit"
                                  name="submit"
                                  id="home-submit"
                                  className="button success btn12"
                                  value="Embed This Video"
                                />
                                &nbsp;&nbsp;
                                   <input
                                  type="submit"
                                  name="submit"
                                  id="home-submit"
                                  className="button success btn12"
                                  value="Generate QR Code"
                                />

                  </div>
                  </div>





                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <script>jQuery(document).foundation();</script>
          </div>

          <Footer />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    VideoData: state.data,
  };
};
export default connect(mapStateToProps, null)(VideoPlayer);
