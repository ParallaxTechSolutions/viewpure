import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  browserHistory,
  IndexRoute,
  Switch,
  Redirect,
} from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import VideoPlayer from "./VideoPlayer";
import { connect } from "react-redux";
import { AddData } from "../action/Data";
class Search extends Component {
  state = {
    videoPath: "",
  };
  onInputChange = (e) => {
    console.log(e.target.value);
    this.setState({ [e.target.name]: e.target.value });
    e.preventDefault();
  };

  YouTubeGetID = () => {
    console.log("ID", this.state.videoPath);
    let ID = this.state.videoPath;

    let url = ID.replace(/(>|<)/gi, "").split(
      /(vi\/|v=|\/v\/|youtu\.be\/|\/embed\/)/
    );
    if (url[2] !== undefined) {
      ID = url[2].split(/[^0-9a-z_\-]/i);
      ID = ID[0];
      console.log("YOUTUBE ID:", ID);
      const data = {
        id: ID,
        path: this.state.videoPath,
      };
      this.props.AddData(data);
      this.props.history.push("/play");
    } else {
      alert("We can't find any video Associated with this Link!");
    }

    // <Route exact path="/play" render={() => <VideoPlayer data={data} />} />
  };

  render() {
    return (
      <div>
        <Navbar />
        <div className="container">
          <div className="ba-comp row">
            <a href="#" className="exm-toggle">
              Examples
            </a>
            <div className="ba-comp-inner">
              <div className="large-10 columns large-centered">
                <div className="row">
                  <div align="center">
                    <script src="//ap.lijit.com/www/delivery/fpi.js?z=396563&width=728&height=90"></script>
                  </div>

                  <div className="large-6 columns"></div>
                  <div className="large-6 columns">
                    <a
                      href="http://viewpure.com/_JmA2ClUvUY"
                      className="exm-link left"
                    >
                      <img
                        src="assets/img/on-viewpure.jpg"
                        alt="A purified video on ViewPure"
                      />
                      <span className="exm-label">On ViewPure</span>
                    </a>
                  </div>
                  <div align="center">
                    <script src="//ap.lijit.com/www/delivery/fpi.js?z=404398&width=728&height=90"></script>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* ================================NEWSECTION============================================================ */}
          <div className="row">
            <div className="large-10 columns large-centered">
              <p>
                Watch purified YouTube videos. Just for teachers, professors,
                social influencers, homeschoolers, and parents...like you.
              </p>
            </div>
          </div>
          <div className="row form-home">
            <div className="large-10 columns large-centered">
              <form
                name="vp-home"
                className="vp-home"
                // action="process.php"
                // method="post"
              >
                <div className="row home-search collapse">
                  <div className="columns large-9 small-7">
                    <input
                      type="text"
                      name="videoPath"
                      id="videoPath"
                      className="text margin-right-in"
                      placeholder="Enter YouTube URL or search term..."
                      onChange={this.onInputChange}
                    />
                  </div>
                  <div className="columns large-1 small-2">
                    <a
                      href="#"
                      className="button options margin-right-in margin-left-in"
                      id="form-options"
                      value="options"
                    >
                      <i className="icon-gear icon-large"></i>
                    </a>
                  </div>
                  <div className="columns large-2 small-3">
                    <input
                      type="submit"
                      name="submit"
                      id="home-submit"
                      className="submit button margin-left-in"
                      value="Search"
                      onClick={this.YouTubeGetID}
                    />
                    <input type="hidden" name="action" value="homePure" />
                  </div>
                </div>
                <div className="row home-options">
                  <div className="columns large-8">
                    <div className="row collapse col-lg-12">
                      <div className="columns small-5">
                        <span className="prefix left-radius margin-right-in">
                          viewpure.com/
                        </span>
                      </div>
                      <div className="columns small-7">
                        <input
                          type="text"
                          className="right-radius margin-left-in"
                          name="customURL"
                          placeholder="Enter custom URL"
                          value=""
                        />
                      </div>
                    </div>
                  </div>
                  <div className="columns large-4">
                    <input
                      type="text"
                      name="password"
                      placeholder="Enter password to protect"
                    />
                  </div>
                </div>
                <div className="row home-options">
                  <div className="columns large-6">
                    <div className="row collapse">
                      <div className="columns small-6">
                        <span className="prefix left-radius">Start Time</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="no-radius text-right margin-right-in"
                          name="startMin"
                          placeholder="Min"
                          value=""
                        />
                        <span className="time-sep">:</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="right-radius margin-left-in"
                          name="startSec"
                          placeholder="Sec"
                          value=""
                        />
                      </div>
                    </div>
                  </div>
                  <div className="columns large-6">
                    <div className="row collapse">
                      <div className="columns small-6">
                        <span className="prefix left-radius">End Time</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="no-radius text-right margin-right-in"
                          name="endMin"
                          placeholder="Min"
                          value=""
                        />
                        <span className="time-sep">:</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="right-radius margin-left-in"
                          name="endSec"
                          placeholder="Sec"
                          value=""
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          {/* ------------------------------------NEWSECTION____________________________________________ */}
          <div className="addcon last-row-small">
            <div className="row">
              <div className="large-12 columns text-center hide-for-small">
                Still having trouble? Maybe try taking the{" "}
                <a href="http://www.viewpure.com/?tour">
                  <u>tour</u> <i className="icon-hand-right"></i>
                </a>
              </div>
              <div className="large-12 txt_color columns text-center show-for-small">
                Still having trouble? Take a look at the{" "}
                <a href="http://viewpure.com/faq">
                  FAQ <i className="icon-hand-right"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="hide-for-small">
            <div
              className="subcon last-row"
              style={{ backgroundColor: "#DBEEFB" }}
            >
              <div className="row">
                <div className="large-6  txt_color columns">
                  <h4>
                    There Are 3 Ways{" "}
                    <b>
                      <u>To Search</u>
                    </b>{" "}
                    For Your Videos:
                  </h4>
                  <br />
                </div>
              </div>
              <div className="row">
                <div className="large-4 columns txt_color">
                  <h3>1. Use The Purify Button</h3>
                  <p>
                    Purify Youtube: Drag this{" "}
                    <a
                      href="javascript:void(location.href='http://viewpure.com/process?bkmrk='+location.href)"
                      className="button bookmarklet small"
                      id="bkmt2"
                    >
                      Purify
                    </a>{" "}
                    button to your bookmark bar (or favorites bar in IE). Click
                    the bookmark on any Youtube page to purify. It's Easy!{" "}
                  </p>
                </div>
                <div className="large-4 columns txt_color">
                  <h3>2. Enter YouTube URL</h3>
                  <p>
                    Purify any YouTube URL that you want. Just enter it in the
                    search box (above). Fantastic!
                    <font size="2">
                      <br />
                      (Like this: https://www.youtube.com/watch?v=_JmA2ClUvUY)
                    </font>
                  </p>
                </div>
                <div className="large-4 columns txt_color">
                  <h3>3. Enter Search Term</h3>
                  <p>
                    Get all the purified videos at your finger tips. Just enter
                    your search term in the search box (above). Simple!{" "}
                  </p>
                </div>
              </div>
            </div>
            <div className="search_page">
              div className="bg15">
              <p className="txt_color bg15 ">
                Try using ViewPure's clean search interface to find the videos
                you want
              </p>
            </div>

            <script>jQuery(document).foundation();</script>
          </div>

          <Footer />
        </div>
      </div>
    );
  }
}

export default connect(null, { AddData })(Search);
