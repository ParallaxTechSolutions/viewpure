export const AddData = (data) => (dispatch) => {
  console.log("Data:", data);
  dispatch({
    type: "ADD_DATA",
    payload: data,
  });
};
// export const ReplaceTask = (data) => (dispatch) => {
//   console.log('REPLACE Data:', data);
//   dispatch({
//     type: 'REPLACE_TASK',
//     payload: data,
//   });
// };
// export const addPost = (data, history) => dispatch => {
//       dispatch({
//         type: "ADD_POST",
//         payload: res.data
//       });

// };

// export const GetTask = (data) => ({
//   type: 'MINUS_COUNT',
//   payload: data,
// });
