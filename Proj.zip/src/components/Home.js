import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  browserHistory,
  IndexRoute,
  Switch,
  Redirect,
} from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { Button, Icon } from '@material-ui/core';
import VideoPlayer from "./VideoPlayer";
import { connect } from "react-redux";
import { AddData } from "../action/Data";
class Home extends Component {
  state = {
    videoPath: "",
  };
  onInputChange = (e) => {
    console.log(e.target.value);
    this.setState({ [e.target.name]: e.target.value });
    e.preventDefault();
  };

  YouTubeGetID = () => {
    console.log("ID", this.state.videoPath);
    let ID = this.state.videoPath;

    let url = ID.replace(/(>|<)/gi, "").split(
      /(vi\/|v=|\/v\/|youtu\.be\/|\/embed\/)/
    );
    if (url[2] !== undefined) {
      ID = url[2].split(/[^0-9a-z_\-]/i);
      ID = ID[0];
      console.log("YOUTUBE ID:", ID);
      const data = {
        id: ID,
        path: this.state.videoPath,
      };
      this.props.AddData(data);
      this.props.history.push("/play");
    } else {
      alert("We can't find any video Associated with this Link!");
    }

    // <Route exact path="/play" render={() => <VideoPlayer data={data} />} />
  };

  render() {
    return (
      <div>
        <Navbar />
<div className="bg-danger w-50 h-50" >
        <Icon color="primary ">setting</Icon>
        </div>
        <div className="container">
          <div className="ba-comp row">
            <a href="#" className="exm-toggle">
              Examples
            </a>
            <div className="ba-comp-inner">
              <div className="large-10 columns large-centered">
                <div className="row">
                  <div align="center">
                    <script src="//ap.lijit.com/www/delivery/fpi.js?z=396563&width=728&height=90"></script>
                  </div>

                  <div className="large-6 columns"></div>
                  <div className="large-6 columns">
                    <a
                      href="http://viewpure.com/_JmA2ClUvUY"
                      className="exm-link left"
                    >
                      <img
                        src="assets/img/on-viewpure.jpg"
                        alt="A purified video on ViewPure"
                      />
                      <span className="exm-label">On ViewPure</span>
                    </a>
                  </div>
                  <div align="center">
                    <script src="//ap.lijit.com/www/delivery/fpi.js?z=404398&width=728&height=90"></script>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* ================================NEWSECTION============================================================ */}
          <div className="row">
            <div className="large-10 columns large-centered">
              <p>
                Watch purified YouTube videos. Just for teachers, professors,
                social influencers, homeschoolers, and parents...like you.
              </p>
            </div>
          </div>
          <div className="row form-home">
            <div className="large-10 columns large-centered">
              <form
                name="vp-home"
                className="vp-home"
                // action="process.php"
                // method="post"
              >
                <div className="row home-search collapse">
                  <div className="columns large-9 small-7">
                    {/* <input
                      type="text"
                      name="videoPath"
                      id="videoPath"
                      className="text margin-right-in"
                      placeholder="Enter YouTube URL or search term..."
                      value=""
                    /> */}
                    <input
                      type="text"
                      name="videoPath"
                      id="videoPath"
                      className="text margin-right-in"
                      placeholder="Enter YouTube URL or search term..."
                      onChange={this.onInputChange}
                    />
                  </div>
                  <div className="columns large-1 small-2">
                    <a
                      href="#"
                      className="button options margin-right-in margin-left-in bg-danger"
                      id="form-options"
                      value="options"
                    >
                     <Icon color="primary">setting</Icon>

                    </a>
                  </div>
                  <div className="columns large-2 small-3">
                    <input
                      type="submit"
                      name="submit"
                      id="home-submit"
                      className="submit button margin-left-in"
                      value="Purify"
                      onClick={this.YouTubeGetID}
                    />
                    <input type="hidden" name="action" value="homePure" />
                  </div>
                </div>
                <div className="row home-options">
                  <div className="columns large-8">
                    <div className="row collapse col-lg-12">
                      <div className="columns small-5">
                        <span className="prefix left-radius margin-right-in">
                          viewpure.com/
                        </span>
                      </div>
                      <div className="columns small-7">
                        <input
                          type="text"
                          className="right-radius margin-left-in"
                          name="customURL"
                          placeholder="Enter custom URL"
                          value=""
                        />
                      </div>
                    </div>
                  </div>
                  <div className="columns large-4">
                    <input
                      type="text"
                      name="password"
                      placeholder="Enter password to protect"
                    />
                  </div>
                </div>
                <div className="row home-options">
                  <div className="columns large-6">
                    <div className="row collapse">
                      <div className="columns small-6">
                        <span className="prefix left-radius">Start Time</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="no-radius text-right margin-right-in"
                          name="startMin"
                          placeholder="Min"
                          value=""
                        />
                        <span className="time-sep">:</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="right-radius margin-left-in"
                          name="startSec"
                          placeholder="Sec"
                          value=""
                        />
                      </div>
                    </div>
                  </div>
                  <div className="columns large-6">
                    <div className="row collapse">
                      <div className="columns small-6">
                        <span className="prefix left-radius">End Time</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="no-radius text-right margin-right-in"
                          name="endMin"
                          placeholder="Min"
                          value=""
                        />
                        <span className="time-sep">:</span>
                      </div>
                      <div className="columns small-3">
                        <input
                          type="text"
                          className="right-radius margin-left-in"
                          name="endSec"
                          placeholder="Sec"
                          value=""
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          {/* ------------------------------------NEWSECTION____________________________________________ */}
          <div className="addcon last-row-small">
            <div className="row">
              <div className="large-12 columns text-center hide-for-small">
                Still having trouble? Maybe try taking the{" "}
                <a href="http://www.viewpure.com/?tour">
                  <u>tour</u> <i className="icon-hand-right"></i>
                </a>
              </div>
              <div className="large-12 txt_color columns text-center show-for-small">
                Still having trouble? Take a look at the{" "}
                <a href="http://viewpure.com/faq">
                  FAQ <i className="icon-hand-right"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="hide-for-small">
            <div
              className="subcon last-row"
              style={{ backgroundColor: "#DBEEFB" }}
            >
              <div className="row">
                <div className="large-6  txt_color columns">
                  <h4>
                    There Are 3 Ways{" "}
                    <b>
                      <u>To Search</u>
                    </b>{" "}
                    For Your Videos:
                  </h4>
                  <br />
                </div>
              </div>
              <div className="row">
                <div className="large-4 columns txt_color">
                  <h3>1. Use The Purify Button</h3>
                  <p>
                    Purify Youtube: Drag this{" "}
                    <a
                      href="javascript:void(location.href='http://viewpure.com/process?bkmrk='+location.href)"
                      className="button bookmarklet small"
                      id="bkmt2"
                    >
                      Purify
                    </a>{" "}
                    button to your bookmark bar (or favorites bar in IE). Click
                    the bookmark on any Youtube page to purify. It's Easy!{" "}
                  </p>
                </div>
                <div className="large-4 columns txt_color">
                  <h3>2. Enter YouTube URL</h3>
                  <p>
                    Purify any YouTube URL that you want. Just enter it in the
                    search box (above). Fantastic!
                    <font size="2">
                      <br />
                      (Like this: https://www.youtube.com/watch?v=_JmA2ClUvUY)
                    </font>
                  </p>
                </div>
                <div className="large-4 columns txt_color">
                  <h3>3. Enter Search Term</h3>
                  <p>
                    Get all the purified videos at your finger tips. Just enter
                    your search term in the search box (above). Simple!{" "}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="rowab containernew">
            <div className="row">
              <h3
                data-magellan-destination="tag-1"
                align="justify"
                className="txt_color floatleft"
              >
                How To Use ViewPure?
              </h3>
              <p className="txt_color" align="justify">
                Let's use the actual video below to see the differences. We have
                always felt that videos speak louder than words. See below.
              </p>
              <div className="row txt_color">
                <a
                  href="http://viewpure.com/_JmA2ClUvUY"
                  className="exm-link left"
                  target="_blank"
                >
                  <img
                    src="assets/img/on-viewpure.jpg"
                    alt="A purified video on ViewPure"
                  />
                  <span className="exm-label">On ViewPure</span>
                </a>
              </div>
              <p align="justify" className="txt_color">
                As you have seen, ViewPure removes all distracting comments and
                side-bar related videos. Which makes the videos you use for your
                school or social media group purified without all the
                distractions or "inappropriate content".
              </p>

              <h3
                align="justify"
                data-magellan-destination="tag-2"
                className="margin_left txt_color"
                id="tag-2"
              >
                What can it be used for?
              </h3>
              <p align="justify" className="txt_color">
                Honestly, what can it <i>not</i> be used for? Common uses
                include:{" "}
              </p>
              <ul align="justify" className="txt_color">
                <li>
                  Removing inappropriate ads and comments from videos to show
                  kids
                </li>
                <li>
                  Removing unwanted related videos at the end to show students
                </li>
                <li>
                  Memorable URLs (youtube.com/watch?v=_JmA2ClUvUY vs
                  viewpure.com/BabyDebate)
                </li>
                <li>YouTube search with a cleaner UI and filtered results</li>
                <li>Cleaner interface to view YouTube videos</li>
              </ul>
              <p align="justify" className="txt_color">
                The list goes on and on - but you will find a use for ViewPure.
              </p>
              <p align="justify" className="txt_color">
                ViewPure has been used by teachers, students, college
                professors, educators, parents, homeschoolers, social
                influencers, organizers, and more.
              </p>
            </div>
            <ul className="abcd accordion" align="justify" data-accordion>
              <li className="accordion-item is-active" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white abcd accordin-title-style"
                >
                  How do I purify a video?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p className="abcd">
                    Step 1: Find a YouTube video you like.
                    <br />
                    Step 2: Paste it into the field on the homepage that says
                    "Enter YouTube URL or search term..."
                    <br />
                    Step 3: Click Purify and enjoy.
                  </p>
                  <p className="abcd">
                    <a href="http://viewpure.com/?tour">Take the tour</a> for
                    more information.
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  How do I purify a video using the Bookmarklet?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    <b>Step 1:</b> Install the Bookmarklet into your Bookmarks
                    in your Browser (Chrome, Safari, Firefox, Microsoft Edge,
                    Opera, Android, and more) <br />
                    <br />
                    Purify Youtube: Drag this{" "}
                    <a
                      href="javascript:void(location.href='http://viewpure.com/process?bkmrk='+location.href)"
                      className="button bookmarklet small"
                      id="bkmt2"
                    >
                      Purify
                    </a>{" "}
                    button to your bookmarks. Click the bookmark on any Youtube
                    page to purify!
                    <br />
                    <br />
                    <b>Step 2:</b> Find a YouTube video you like and click the
                    ViewPure Bookmarklet
                    <br />
                    <b>Step 3:</b> The Bookmarklet will take you to the
                    "purified" page on ViewPure.com to watch your video...free
                    of YouTube distractions. Yeah!
                    <br />
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  Why are there still ads?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    Our videos don't have ads. But some other parts of the site
                    do. They help pay for domain fees, server costs, Clicky
                    Analytics, and other maintenance costs so we can keep
                    ViewPure going.
                  </p>
                  <p>
                    Some videos will always have ads, no matter where they are
                    viewed or embedded. Unfortunately, there is nothing that can
                    be done from ViewPure, however, at least there aren't trolls
                    and distasteful comments, right?
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  What is the Viewpure Membership Area?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    The Viewpure Members Area is the place where viewpure can
                    give you additional tools and resources. The Members Area is
                    FREE. There is a lot of cool stuff in there for clean
                    viewing of videos. You'll love it.{" "}
                  </p>
                  <p>
                    This is the link to the FREE Signup Here:{" "}
                    <a href="https://members.viewpure.com/signup">
                      https://members.viewpure.com/signup
                    </a>{" "}
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  Why do I get the no video error?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    Some videos from YouTube aren't allowed to be embedded, so
                    we are unable to show them. Again, there is nothing we can
                    really do to work around this issue.
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  How do I use the bookmarklet?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    To use the bookmarklet, simply drag the bookmarklet link to
                    your bookmarks toolbar. After you have done that, simply
                    click the "Purify" link in your bookmarks toolbar whenever
                    you are on any YouTube page and it will automatically remove
                    ads, comments, and other clutter.
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  Error with the bookmarklet?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    If you keep getting errors when trying to use the
                    bookmarklet, it is very likely that you are using an
                    outdated version of it, either obtained from a previous
                    version of the site or from a third-party site. To fix this,
                    go to the homepage and reinstall the bookmarklet.
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  What's the custom URL?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    The custom URL feature on here allows you to create easily
                    memorable URLs like viewpure.com/BabyDebate, as opposed to
                    youtube.com/watch?v=_JmA2ClUvUY. Most custom URLs are kept
                    indefinitely, though some are pruned if the view count drops
                    below 10 over a 6 month period.
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  Why was my custom URL rejected?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    Your custom URL has to be both alphanumeric (A-Z, 0-9, no
                    special characters) and available. In addition it cannot be
                    exactly 11 characters, to avoid conflicts with YouTube IDs
                    (which are 11 characters long).
                  </p>
                  <p>
                    If you are sure your custom URL follows the rules, then it's
                    likely that somebody else already took the custom URL you
                    wanted, in which case try variations such as
                    viewpure.com/TheCustomURL or viewpure.com/CustomURL2.
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  What is password protection?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    Password protection allows you to create a
                    publicly-accessible link to a purified video with a password
                    protecting it. In other words, visitors and users need to
                    enter the custom password you specified in order for them to
                    be able to see the video you set.
                  </p>
                </div>
              </li>
              <li className="accordion-item abcd" data-accordion-item>
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  What is the start / end time?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    Sometimes you really only want to show a specific portion of
                    the video, and let's be honest, dragging the progress
                    tracker disc gets to be a hassle sometimes. Next time, just
                    use ViewPure to set a start and end time for the video, and
                    every time you load your custom URL, it will play and stop
                    exactly where you want.
                  </p>
                </div>
              </li>
              <li
                className="accordion-item text_white abcd"
                data-accordion-item
              >
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  Why can't I find a specific video?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    Only videos that are available and embeddable are shown,
                    though some adult videos may be filtered as well. To
                    circumvent this, just set the filter bar from SafeSearch to
                    None.
                  </p>
                </div>
              </li>
              <li
                className="accordion-item abcd text_white"
                data-accordion-item
              >
                <a
                  href="#"
                  className="accordion-title text-white accordin-title-style"
                >
                  How do I use the filters?
                </a>
                <div className="accordion-content" data-tab-content>
                  <p>
                    Click the dropdown select menu to select between the three
                    main filters for searches:
                  </p>
                  <ul>
                    <li>
                      <strong>SafeSearch:</strong> Controls the content you want
                      shown in search results (default: strict)
                    </li>
                    <li>
                      <strong>Sort By:</strong> Controls how the results are
                      sorted (default: relevance)
                    </li>
                    <li>
                      <strong>Results Per Page:</strong> Controls how many
                      results are shown at once (default: 12)
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
            <Footer />

          </div>

        </div>
      </div>
    );
  }
}

export default connect(null, { AddData })(Home);
