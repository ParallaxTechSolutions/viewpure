// import {act} from 'react-test-renderer';

const initialState = {
  data: "",
};
export default (state = initialState, action) => {
  switch (action.type) {
    case "ADD_DATA":
      console.log("Red:", action.payload);
      let newData = action.payload;
      return { ...state, data: newData };
    case "REPLACE_TASK":
      // let newData = [...state.tasks, action.payload];
      console.log("Action REPLACE Reducer:", action.payload);
      let repTask = action.payload;
      return { ...state, task: repTask };

    default:
      return state;
  }
};
